from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.db.models import Q 


# Create your views here.
@login_required(login_url='login')

def home_page(request):
    return render(request,'home.html')
    

def signup_page(request):
    if request.method=='POST':
        uname=request.POST.get('username')
        email=request.POST.get('email')
        pass1=request.POST.get('password1')
        pass2=request.POST.get('password2')

        if pass1!=pass2:
            return HttpResponse("your password is not matched")
        else:

         my_user=User.objects.create_user(uname,email,pass1)
         my_user.is_active = True
         my_user.save()
         return redirect('login')


    return render(request,'signup.html')


def login_page(request):
    if request.method == 'POST':
    
        username_or_email = request.POST.get('username', '').strip() 
        pass1 = request.POST.get('password', '').strip()  
        
        
        if not username_or_email or not pass1:
            return HttpResponse("Username and password fields cannot be empty")

        
        user = User.objects.filter(Q(username=username_or_email) | Q(email=username_or_email)).first()

        if user:
            
            user = authenticate(request, username=user.username, password=pass1)

        if user is not None:
            login(request, user)
            return redirect('homepage')
        else:
            return HttpResponse("Username or password is incorrect!!")

    return render(request, 'login.html')


def logout_page(request):
    logout(request)
    return redirect('login')